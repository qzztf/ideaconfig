create view v_role_type as
  select `role`.`ID_`         AS `ID_`,
         `role`.`NAME_`       AS `NAME_`,
         `role`.`ALIAS_`      AS `ALIAS_`,
         `role`.`ENABLED_`    AS `ENABLED_`,
         `role`.`DESCRIPTION` AS `DESCRIPTION`,
         `type`.`TYPE_KEY_`   AS `TYPE_KEY_`,
         `type`.`NAME_`       AS `type_name`
  from (`bpms_152`.`sys_role` `role` left join `bpms_152`.`sys_role_type` `type` on ((`role`.`ID_` =
                                                                                      `type`.`ROLE_ID_`)));

