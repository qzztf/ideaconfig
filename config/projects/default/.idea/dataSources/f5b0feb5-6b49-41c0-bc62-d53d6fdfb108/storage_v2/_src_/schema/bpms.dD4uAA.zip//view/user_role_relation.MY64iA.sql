create view user_role_relation as
  select `t`.`id_` AS `userId`, `t2`.`NAME_` AS `roleName`, `t2`.`ID_` AS `roleId`
  from ((`bpms`.`sys_user` `t` join `bpms`.`sys_user_role` `t1`) join `bpms`.`sys_role` `t2`)
  where ((`t`.`id_` = `t1`.`user_id_`) and (`t1`.`role_id_` = `t2`.`ID_`));

