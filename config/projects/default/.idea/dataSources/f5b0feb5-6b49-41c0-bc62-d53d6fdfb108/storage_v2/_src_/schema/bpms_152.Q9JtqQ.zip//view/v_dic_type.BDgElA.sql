create view v_dic_type as
  select `a`.`ID_`        AS `DIC_ID_`,
         `a`.`TYPE_ID_`   AS `TYPE_ID_`,
         `a`.`KEY_`       AS `DIC_KEY_`,
         `a`.`NAME_`      AS `DIC_NAME_`,
         `a`.`PARENT_ID_` AS `DIC_PARENT_ID_`,
         `a`.`SN_`        AS `DIC_SN_`,
         `b`.`NAME_`      AS `TYPE_NAME_`,
         `b`.`TYPE_KEY_`  AS `TYPE_KEY_`
  from (`bpms_152`.`sys_dic` `a` join `bpms_152`.`sys_type` `b` on ((`a`.`TYPE_ID_` = `b`.`ID_`)))
  where (`a`.`TYPE_ID_` = `b`.`ID_`);

