create view v_grant_post as (select `t`.`ID_`                                          AS `ID_`,
                                    concat(left(`o`.`NAME_`, 2), '-', `t`.`REL_NAME_`) AS `orgRel`,
                                    `t`.`ORG_ID_`                                      AS `ORG_ID_`,
                                    `t`.`REL_DEF_ID_`                                  AS `REL_DEF_ID_`,
                                    `t`.`REL_NAME_`                                    AS `REL_NAME_`,
                                    `t`.`REL_CODE_`                                    AS `REL_CODE_`,
                                    `o`.`ID_`                                          AS `orgId`,
                                    `o`.`NAME_`                                        AS `orgName`
                             from (`bpms_152`.`sys_org_rel` `t` left join `bpms_152`.`sys_org` `o` on ((`t`.`ORG_ID_` =
                                                                                                        `o`.`ID_`))));

