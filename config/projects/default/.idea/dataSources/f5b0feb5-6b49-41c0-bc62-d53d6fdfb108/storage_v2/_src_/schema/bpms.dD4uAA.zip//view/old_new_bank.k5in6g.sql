create view old_new_bank as
  select substr(`a`.`bank_class_code`, 1, 3) AS `old_bank_class`,
         `a`.`bank_class_code`               AS `new_bank_class`,
         `a`.`bank_class_name`               AS `bank_class_name`
  from `bpms`.`s_bank_class` `a`
  where (substr(`a`.`bank_class_code`, 1, 3) not in ('313', '314', '323', '402'));

