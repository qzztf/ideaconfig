create view v_bank_trust as
  select `b`.`bank_class_code`        AS `bank_class_code`,
         `b`.`bank_class_name`        AS `bank_class_name`,
         `b`.`bank_type`              AS `bank_type`,
         `p`.`partner_serial`         AS `partner_serial`,
         `p`.`partner_id`             AS `partner_id`,
         `p`.`partner_name`           AS `partner_name`,
         `p`.`partner_type`           AS `partner_type`,
         `p`.`unionPay_alliance_code` AS `unionPay_alliance_code`,
         `p`.`cooperate_type`         AS `cooperate_type`,
         `p`.`partner_director`       AS `partner_director`,
         `p`.`contact_phone`          AS `contact_phone`,
         `p`.`partner_level`          AS `partner_level`,
         `p`.`superior_partner_id`    AS `superior_partner_id`,
         `p`.`belong_city`            AS `belong_city`,
         `p`.`belong_area`            AS `belong_area`,
         `p`.`partner_cert_id`        AS `partner_cert_id`,
         `p`.`partner_mail_address`   AS `partner_mail_address`,
         `p`.`partner_address`        AS `partner_address`,
         `p`.`partner_status`         AS `partner_status`,
         `p`.`start_datetime`         AS `start_datetime`,
         `p`.`end_datetime`           AS `end_datetime`,
         `p`.`branch_id`              AS `branch_id`,
         `p`.`manage_user_list`       AS `manage_user_list`
  from (`bpms`.`s_bank_class` `b` join `bpms`.`s_partner_info` `p`)
  where (`p`.`partner_type` = 'NTR');

