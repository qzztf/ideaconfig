create view plat_due_date_view as
  select `bpms_152`.`biz_fee_summary`.`apply_no`                    AS `apply_no`,
         (`bpms_152`.`biz_fee_summary`.`platform_value_date` +
          interval `bpms_152`.`biz_fee_summary`.`product_term` day) AS `platform_due_date`,
         `bpms_152`.`biz_fee_summary`.`platform_value_date`         AS `platform_value_date`,
         `bpms_152`.`biz_fee_summary`.`product_term`                AS `product_term`
  from `bpms_152`.`biz_fee_summary`
  where ((`bpms_152`.`biz_fee_summary`.`platform_value_date` is not null) and
         (`bpms_152`.`biz_fee_summary`.`platform_value_date` <> '') and
         (`bpms_152`.`biz_fee_summary`.`product_term` is not null) and
         (`bpms_152`.`biz_fee_summary`.`product_term` <> ''));

