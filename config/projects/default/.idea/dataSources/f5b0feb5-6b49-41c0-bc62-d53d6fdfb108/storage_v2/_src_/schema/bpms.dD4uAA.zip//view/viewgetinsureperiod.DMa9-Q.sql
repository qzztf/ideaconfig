create view viewgetinsureperiod as
  select `a`.`partner_id`        AS `insureId`,
         `a`.`product_name`      AS `productName`,
         `a`.`day_before_expire` AS `dayBeforeExpire`,
         `a`.`link_partner_id`   AS `bankName`
  from (`bpms`.`s_finance_channel` `a` left join `bpms`.`s_partner_info` `b` on ((`a`.`partner_id` =
                                                                                  `b`.`partner_id`)));

