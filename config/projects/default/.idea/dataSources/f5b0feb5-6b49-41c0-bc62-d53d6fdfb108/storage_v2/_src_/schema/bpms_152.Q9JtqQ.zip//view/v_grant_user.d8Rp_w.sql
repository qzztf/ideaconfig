create view v_grant_user as
  select distinct `t`.`id_`       AS `id_`,
                  `t`.`fullname_` AS `fullname_`,
                  `t`.`account_`  AS `account_`,
                  `b`.`NAME_`     AS `NAME_`,
                  `b`.`ID_`       AS `orgId`,
                  `t`.`status_`   AS `status_`
  from ((`bpms_152`.`sys_user` `t` left join `bpms_152`.`sys_org_user` `a` on ((`t`.`id_` =
                                                                                `a`.`USER_ID_`))) left join `bpms_152`.`sys_org` `b` on ((
    `b`.`ID_` = `a`.`ORG_ID_`)));

