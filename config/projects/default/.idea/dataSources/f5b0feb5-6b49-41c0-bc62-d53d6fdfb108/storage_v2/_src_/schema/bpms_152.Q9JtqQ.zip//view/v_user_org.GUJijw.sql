create view v_user_org as
  select distinct `u`.`id_`                           AS `id_`,
                  `u`.`fullname_`                     AS `fullname_`,
                  `u`.`account_`                      AS `account_`,
                  `u`.`password_`                     AS `password_`,
                  `u`.`email_`                        AS `email_`,
                  `u`.`mobile_`                       AS `mobile_`,
                  `u`.`weixin_`                       AS `weixin_`,
                  `u`.`create_time_`                  AS `create_time_`,
                  `u`.`address_`                      AS `address_`,
                  `u`.`photo_`                        AS `photo_`,
                  `u`.`sex_`                          AS `sex_`,
                  `u`.`from_`                         AS `from_`,
                  `u`.`status_`                       AS `status_`,
                  `o`.`CODE_`                         AS `orgCode`,
                  concat(left(`o`.`CODE_`, 3), '000') AS `companyCode`,
                  `o`.`NAME_`                         AS `orgName`,
                  `o`.`ID_`                           AS `orgId`
  from ((`bpms_152`.`sys_org_user` `ou` left join `bpms_152`.`sys_org` `o` on ((`ou`.`ORG_ID_` =
                                                                                `o`.`ID_`))) left join `bpms_152`.`sys_user` `u` on ((
    `u`.`id_` = `ou`.`USER_ID_`)))
  where (`u`.`id_` is not null);

