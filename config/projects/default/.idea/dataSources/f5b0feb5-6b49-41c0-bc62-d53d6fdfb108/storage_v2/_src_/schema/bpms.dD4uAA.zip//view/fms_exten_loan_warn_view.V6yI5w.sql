create view fms_exten_loan_warn_view as
  select `fund`.`apply_no` AS `apply_no`, `fms`.`begin_time` AS `begin_time`
  from (`bpms`.`c_fund_module` `fund` join `bpms`.`fms_exten_loan` `fms` on ((`fund`.`id` = `fms`.`deal_serial_no`)));

