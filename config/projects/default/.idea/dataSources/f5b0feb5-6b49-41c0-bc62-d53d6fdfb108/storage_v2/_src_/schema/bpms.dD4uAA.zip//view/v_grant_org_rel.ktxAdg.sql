create view v_grant_org_rel as
  select `t`.`ID_`                                          AS `ID_`,
         concat(left(`o`.`NAME_`, 2), '-', `t`.`REL_NAME_`) AS `orgRel`,
         `t`.`ORG_ID_`                                      AS `ORG_ID_`,
         `t`.`REL_DEF_ID_`                                  AS `REL_DEF_ID_`,
         `t`.`REL_NAME_`                                    AS `REL_NAME_`,
         `t`.`REL_CODE_`                                    AS `REL_CODE_`,
         `rd`.`TYPE_`                                       AS `type_`,
         `rd`.`POST_LEVEL_`                                 AS `post_level_`,
         `o`.`ID_`                                          AS `orgId`,
         `o`.`NAME_`                                        AS `orgName`
  from ((`bpms`.`sys_org_rel` `t` join `bpms`.`sys_org_reldef` `rd` on ((`t`.`REL_DEF_ID_` =
                                                                         `rd`.`ID_`))) left join `bpms`.`sys_org` `o` on ((
    `t`.`ORG_ID_` = `o`.`ID_`)));

