create view v_fd_ret as
  select `fd`.`apply_no`  AS `apply_no`,
         `fd`.`fin_date`  AS `fin_date`,
         `ret`.`fin_date` AS `ret_fin_date`,
         `fd`.`adv_type`  AS `adv_type`
  from (`bpms_152`.`fd_advance` `fd` left join `bpms_152`.`fd_advance_ret` `ret` on ((`fd`.`id` = `ret`.`apply_id`)));

