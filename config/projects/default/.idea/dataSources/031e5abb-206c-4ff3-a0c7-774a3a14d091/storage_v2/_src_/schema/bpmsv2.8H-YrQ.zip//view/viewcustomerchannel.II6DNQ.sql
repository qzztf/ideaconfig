create view viewcustomerchannel as select `a`.`apply_no` AS `applyNo`,
                                          `d`.`NAME_`    AS `roleName`,
                                          `b`.`name`     AS `NAME`,
                                          `a`.`relation` AS `relationName`
                                   from ((`bpmsv2`.`biz_customer_rel` `a` join `bpmsv2`.`biz_customer` `b` on ((
                                     `a`.`customer_no` = `b`.`cust_no`))) join `bpmsv2`.`sys_dic` `d` on ((`a`.`role` =
                                                                                                           `d`.`KEY_`)))
                                   where (`d`.`TYPE_ID_` = '10000001220223')
                                   union all select `d`.`apply_no`     AS `applyNo`,
                                                    '渠道'               AS `roleName`,
                                                    `d`.`channel_name` AS `NAME`,
                                                    ''                 AS `relationName`
                                             from `bpmsv2`.`biz_channel` `d`;

