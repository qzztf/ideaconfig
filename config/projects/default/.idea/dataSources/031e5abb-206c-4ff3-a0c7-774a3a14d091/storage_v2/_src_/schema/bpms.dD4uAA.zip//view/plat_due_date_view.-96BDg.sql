create view plat_due_date_view as
  select `bpms`.`biz_fee_summary`.`apply_no`                                                                     AS `apply_no`,
         (`bpms`.`biz_fee_summary`.`platform_value_date` +
          interval `bpms`.`biz_fee_summary`.`product_term` day)                                                  AS `platform_due_date`,
         `bpms`.`biz_fee_summary`.`platform_value_date`                                                          AS `platform_value_date`,
         `bpms`.`biz_fee_summary`.`product_term`                                                                 AS `product_term`
  from `bpms`.`biz_fee_summary`
  where ((`bpms`.`biz_fee_summary`.`platform_value_date` is not null) and
         (`bpms`.`biz_fee_summary`.`platform_value_date` <> '') and
         (`bpms`.`biz_fee_summary`.`product_term` is not null) and (`bpms`.`biz_fee_summary`.`product_term` <> ''));

