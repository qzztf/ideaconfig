create view v_user_post_relation as
  select `t`.`USER_ID_`                                     AS `USER_ID_`,
         `a`.`ID_`                                          AS `ID_`,
         `a`.`REL_NAME_`                                    AS `REL_NAME_`,
         `b`.`CODE_`                                        AS `CODE_`,
         `b`.`NAME_`                                        AS `NAME_`,
         concat(left(`b`.`NAME_`, 2), '-', `a`.`REL_NAME_`) AS `orgRel`,
         `a`.`REL_DEF_ID_`                                  AS `REL_DEF_ID_`,
         `a`.`REL_CODE_`                                    AS `REL_CODE_`,
         `d`.`TYPE_`                                        AS `type_`,
         `d`.`POST_LEVEL_`                                  AS `post_level_`,
         `d`.`CODE_`                                        AS `RELDEF_CODE_`
  from (((`bpms`.`sys_org_user` `t` left join `bpms`.`sys_org_rel` `a` on ((`t`.`REL_ID_` =
                                                                            `a`.`ID_`))) join `bpms`.`sys_org_reldef` `d` on ((
    `a`.`REL_DEF_ID_` = `d`.`ID_`))) left join `bpms`.`sys_org` `b` on ((`b`.`ID_` = `a`.`ORG_ID_`)));

