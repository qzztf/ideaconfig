create view v_order_personalcl as
  select `bpmsv2`.`biz_personal_litigation`.`id`                 AS `id`,
         `bpmsv2`.`biz_personal_litigation`.`customer_name`      AS `customer_name`,
         `bpmsv2`.`biz_personal_litigation`.`query_time`         AS `query_time`,
         `bpmsv2`.`biz_personal_litigation`.`has_eco_litigation` AS `has_eco_litigation`,
         `bpmsv2`.`biz_personal_litigation`.`hass_unfinish_exec` AS `hass_unfinish_exec`,
         `bpmsv2`.`biz_personal_litigation`.`query_result`       AS `query_result`,
         `bpmsv2`.`biz_personal_litigation`.`query_user_id`      AS `query_user_id`,
         `bpmsv2`.`biz_personal_litigation`.`query_user_name`    AS `query_user_name`,
         `bpmsv2`.`biz_personal_litigation`.`tongdun_result`     AS `tongdun_result`,
         `bpmsv2`.`biz_personal_litigation`.`remark`             AS `remark`,
         `bpmsv2`.`biz_personal_litigation`.`create_user_id`     AS `create_user_id`,
         `bpmsv2`.`biz_personal_litigation`.`update_user_id`     AS `update_user_id`,
         `bpmsv2`.`biz_personal_litigation`.`create_time`        AS `create_time`,
         `bpmsv2`.`biz_personal_litigation`.`update_time`        AS `update_time`,
         `bpmsv2`.`biz_personal_litigation`.`rev`                AS `rev`,
         `bpmsv2`.`biz_personal_litigation`.`delete_flag`        AS `delete_flag`,
         `bpmsv2`.`biz_personal_litigation`.`type`               AS `type`,
         `bpmsv2`.`biz_personal_litigation`.`flag`               AS `flag`,
         `bpmsv2`.`biz_personal_litigation`.`type_json`          AS `type_json`,
         `bpmsv2`.`biz_customer_rel`.`customer_no`               AS `customer_no`,
         `bpmsv2`.`biz_customer_rel`.`apply_no`                  AS `apply_no`
  from (`bpmsv2`.`biz_customer_rel` join `bpmsv2`.`biz_personal_litigation` on ((
    `bpmsv2`.`biz_customer_rel`.`customer_no` = `bpmsv2`.`biz_personal_litigation`.`customer_no`)));

