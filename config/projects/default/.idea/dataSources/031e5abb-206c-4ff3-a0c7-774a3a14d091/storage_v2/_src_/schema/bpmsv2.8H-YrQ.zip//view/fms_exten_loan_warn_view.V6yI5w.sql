create view fms_exten_loan_warn_view as
  select `fund`.`apply_no` AS `apply_no`, `fms`.`begin_time` AS `begin_time`
  from (`bpmsv2`.`c_fund_module` `fund` join `bpmsv2`.`fms_exten_loan` `fms` on ((`fund`.`id` =
                                                                                  `fms`.`deal_serial_no`)));

