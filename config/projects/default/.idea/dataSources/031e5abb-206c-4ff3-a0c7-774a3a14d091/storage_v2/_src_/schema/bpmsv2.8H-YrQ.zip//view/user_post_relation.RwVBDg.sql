create view user_post_relation as
  select `t`.`USER_ID_`                                     AS `USER_ID_`,
         `a`.`ID_`                                          AS `ID_`,
         `a`.`REL_NAME_`                                    AS `REL_NAME_`,
         `b`.`CODE_`                                        AS `CODE_`,
         `b`.`NAME_`                                        AS `NAME_`,
         concat(left(`b`.`NAME_`, 2), '-', `a`.`REL_NAME_`) AS `orgRel`
  from ((`bpmsv2`.`sys_org_user` `t` left join `bpmsv2`.`sys_org_rel` `a` on ((`t`.`REL_ID_` =
                                                                               `a`.`ID_`))) left join `bpmsv2`.`sys_org` `b` on ((
    `b`.`ID_` = `a`.`ORG_ID_`)));

