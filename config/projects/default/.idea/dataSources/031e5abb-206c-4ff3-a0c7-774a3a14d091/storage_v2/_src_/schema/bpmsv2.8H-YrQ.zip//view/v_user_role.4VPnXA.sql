create view v_user_role as
  select `a`.`id_`          AS `id_`,
         `a`.`fullname_`    AS `fullname_`,
         `a`.`account_`     AS `account_`,
         `a`.`password_`    AS `password_`,
         `a`.`email_`       AS `email_`,
         `a`.`mobile_`      AS `mobile_`,
         `a`.`weixin_`      AS `weixin_`,
         `a`.`create_time_` AS `create_time_`,
         `a`.`address_`     AS `address_`,
         `a`.`photo_`       AS `photo_`,
         `a`.`sex_`         AS `sex_`,
         `a`.`from_`        AS `from_`,
         `a`.`status_`      AS `status_`,
         `c`.`REL_CODE_`    AS `rel_code_`
  from ((`bpmsv2`.`sys_user` `a` left join `bpmsv2`.`sys_org_user` `b` on ((`a`.`id_` =
                                                                            `b`.`USER_ID_`))) left join `bpmsv2`.`sys_org_rel` `c` on ((
    `c`.`ORG_ID_` = `b`.`ORG_ID_`)))
  where (`c`.`ID_` = `b`.`REL_ID_`);

