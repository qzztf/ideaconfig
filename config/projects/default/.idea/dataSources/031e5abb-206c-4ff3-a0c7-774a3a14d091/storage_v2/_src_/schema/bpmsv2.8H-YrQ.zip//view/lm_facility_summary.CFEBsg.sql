create view lm_facility_summary as
  select `lmf`.`facility_code`                                                                                                        AS `facility_code`,
         `lmf`.`facility_desc`                                                                                                        AS `facility_desc`,
         `lmf`.`code_1`                                                                                                               AS `code_1`,
         ifnull((select `bpmsv2`.`lm_facility_lmt`.`interview_amt`
                 from `bpmsv2`.`lm_facility_lmt`
                 where ((`bpmsv2`.`lm_facility_lmt`.`code_1` = `lmf`.`code_1`) and
                        isnull(`bpmsv2`.`lm_facility_lmt`.`code_2`) and isnull(`bpmsv2`.`lm_facility_lmt`.`code_3`) and
                        isnull(`bpmsv2`.`lm_facility_lmt`.`code_4`))),
                0)                                                                                                                    AS `code_1_amt`,
         ifnull(((select `t1`.`exp_bal`
                  from (`bpmsv2`.`lm_exposure_bal` `t1` join `bpmsv2`.`lm_facility_lmt` `t2`)
                  where ((`t1`.`code_1` = `t2`.`code_1`) and isnull(`t1`.`code_2`) and isnull(`t1`.`code_3`) and
                         isnull(`t1`.`code_4`) and (`t2`.`facility_code` = `lmf`.`facility_code`) and
                         (`t1`.`value_date` = (curdate() + interval -(1) day)))) + ifnull((select sum(
                                                                                                    ((case `bpmsv2`.`lm_exposure`.`add_ded`
                                                                                                        when 'A' then 1
                                                                                                        when 'U' then 0
                                                                                                        else -(1) end) *
                                                                                                     `bpmsv2`.`lm_exposure`.`amount`))
                                                                                           from `bpmsv2`.`lm_exposure`
                                                                                           where ((`bpmsv2`.`lm_exposure`.`facility_ref` like `lmf`.`facility_code`) and
                                                                                                  (`bpmsv2`.`lm_exposure`.`value_date` = curdate()))),
                                                                                          0)),
                0)                                                                                                                    AS `code_1_bal`,
         `lmf`.`code_2`                                                                                                               AS `code_2`,
         ifnull((select `bpmsv2`.`lm_facility_lmt`.`interview_amt`
                 from `bpmsv2`.`lm_facility_lmt`
                 where ((`bpmsv2`.`lm_facility_lmt`.`code_1` = `lmf`.`code_1`) and
                        (`bpmsv2`.`lm_facility_lmt`.`code_2` = `lmf`.`code_2`) and
                        isnull(`bpmsv2`.`lm_facility_lmt`.`code_3`) and isnull(`bpmsv2`.`lm_facility_lmt`.`code_4`))),
                0)                                                                                                                    AS `code_2_amt`,
         `lmf`.`code_4`                                                                                                               AS `code_4`,
         `lmf`.`code_3`                                                                                                               AS `code_3`,
         `lmf`.`interview_amt`                                                                                                        AS `interview_amt`,
         `lmf`.`loan_amt`                                                                                                             AS `loan_amt`,
         (select count(1)
          from `bpmsv2`.`lm_exposure_book` `leb`
          where ((`leb`.`facility_ref` like `lmf`.`facility_code`) and (`leb`.`add_ded` = 'A') and (not(exists(select 1
                                                                                                               from `bpmsv2`.`lm_exposure_book` `t1`
                                                                                                               where ((`t1`.`apply_no` = `leb`.`apply_no`) and
                                                                                                                      (`t1`.`facility_ref` = `leb`.`facility_ref`) and
                                                                                                                      (`t1`.`add_ded` in (
                                                                                                                          'R',
                                                                                                                          'D')))))))) AS `mq_cnt`,
         ifnull(((select `bpmsv2`.`lm_exposure_bal`.`freeze_bal`
                  from `bpmsv2`.`lm_exposure_bal`
                  where ((`bpmsv2`.`lm_exposure_bal`.`facility_code` = `lmf`.`facility_code`) and
                         (`bpmsv2`.`lm_exposure_bal`.`value_date` = (curdate() + interval -(1) day)))) + ifnull(
                                                                                                           (select sum(
                                                                                                                     ((case `bpmsv2`.`lm_exposure_book`.`add_ded`
                                                                                                                         when 'A'
                                                                                                                                 then 1
                                                                                                                         when 'U'
                                                                                                                                 then 0
                                                                                                                         else -(1) end) *
                                                                                                                      `bpmsv2`.`lm_exposure_book`.`amount`))
                                                                                                            from `bpmsv2`.`lm_exposure_book`
                                                                                                            where ((`bpmsv2`.`lm_exposure_book`.`facility_ref` like `lmf`.`facility_code`) and
                                                                                                                   (`bpmsv2`.`lm_exposure_book`.`value_date` = curdate()))),
                                                                                                           0)),
                0)                                                                                                                    AS `mq_amt`,
         (select count(1)
          from `bpmsv2`.`lm_exposure_book`
          where ((`bpmsv2`.`lm_exposure_book`.`facility_ref` like `lmf`.`facility_code`) and
                 (`bpmsv2`.`lm_exposure_book`.`add_ded` = 'R')))                                                                      AS `td_cnt`,
         ifnull((select sum(`bpmsv2`.`lm_exposure_book`.`amount`)
                 from `bpmsv2`.`lm_exposure_book`
                 where ((`bpmsv2`.`lm_exposure_book`.`facility_ref` like `lmf`.`facility_code`) and
                        (`bpmsv2`.`lm_exposure_book`.`add_ded` = 'R'))),
                0)                                                                                                                    AS `td_amt`,
         (select count(1)
          from `bpmsv2`.`lm_exposure` `lme`
          where ((`lme`.`facility_ref` like `lmf`.`facility_code`) and (`lme`.`add_ded` = 'A') and (not(exists(select 1
                                                                                                               from `bpmsv2`.`lm_exposure` `t1`
                                                                                                               where ((`t1`.`apply_no` = `lme`.`apply_no`) and
                                                                                                                      (`t1`.`facility_ref` = `lme`.`facility_ref`) and
                                                                                                                      (`t1`.`add_ded` in (
                                                                                                                          'R',
                                                                                                                          'D')))))))) AS `fk_cnt`,
         ifnull(((select `bpmsv2`.`lm_exposure_bal`.`exp_bal`
                  from `bpmsv2`.`lm_exposure_bal`
                  where ((`bpmsv2`.`lm_exposure_bal`.`facility_code` = `lmf`.`facility_code`) and
                         (`bpmsv2`.`lm_exposure_bal`.`value_date` = (curdate() + interval -(1) day)))) + ifnull(
                                                                                                           (select sum(
                                                                                                                     ((case `bpmsv2`.`lm_exposure`.`add_ded`
                                                                                                                         when 'A'
                                                                                                                                 then 1
                                                                                                                         when 'U'
                                                                                                                                 then 0
                                                                                                                         else -(1) end) *
                                                                                                                      `bpmsv2`.`lm_exposure`.`amount`))
                                                                                                            from `bpmsv2`.`lm_exposure`
                                                                                                            where ((`bpmsv2`.`lm_exposure`.`facility_ref` like `lmf`.`facility_code`) and
                                                                                                                   (`bpmsv2`.`lm_exposure`.`value_date` = curdate()))),
                                                                                                           0)),
                0)                                                                                                                    AS `fk_amt`,
         (select count(1)
          from `bpmsv2`.`lm_exposure`
          where ((`bpmsv2`.`lm_exposure`.`facility_ref` like `lmf`.`facility_code`) and
                 (`bpmsv2`.`lm_exposure`.`add_ded` = 'D')))                                                                           AS `hk_cnt`,
         ifnull((select sum(`bpmsv2`.`lm_exposure`.`amount`)
                 from `bpmsv2`.`lm_exposure`
                 where ((`bpmsv2`.`lm_exposure`.`facility_ref` like `lmf`.`facility_code`) and
                        (`bpmsv2`.`lm_exposure`.`add_ded` = 'D'))),
                0)                                                                                                                    AS `hk_amt`
  from `bpmsv2`.`lm_facility_lmt` `lmf`;

