create view viewbankinsurancerel as
  select `a`.`partner_id`             AS `bankId`,
         `a`.`partner_name`           AS `bankName`,
         `a`.`partner_name`           AS `insured_name`,
         `a`.`contact_phone`          AS `insured_phone`,
         `a`.`unionPay_alliance_code` AS `insured_cret_id`,
         `a`.`partner_mail_address`   AS `insured_mail`,
         `b`.`delete_flag`            AS `delete_flag`,
         `b`.`product_name`           AS `productName`,
         `b`.`day_before_expire`      AS `insurance_period`,
         `c`.`partner_id`             AS `insuranceId`,
         `c`.`partner_name`           AS `insuranceName`,
         `d`.`branch_code`            AS `bankCity`,
         `e`.`branch_code`            AS `insuranceCity`,
         `f`.`apply_no`               AS `applyNo`
  from ((((`bpms`.`s_finance_channel` `b` left join (`bpms`.`s_partner_info` `a` left join `bpms`.`s_area_info` `d` on ((
    (`a`.`belong_city` = `d`.`id`) and
    (`a`.`partner_name` not in ('南粤金服平台', '真融宝-大桔网', '小赢理财', '南粤信贷资金', '真融宝-盈华小贷'))))) on ((`a`.`partner_id` =
                                                                                            `b`.`link_partner_id`))) left join `bpms`.`s_partner_info` `c` on ((
    (`b`.`partner_id` = `c`.`partner_id`) and (`c`.`partner_name` not in
                                               ('南粤金服平台', '真融宝-大桔网', '小赢理财', '南粤信贷资金', '真融宝-盈华小贷'))))) left join `bpms`.`s_area_info` `e` on ((
    `c`.`belong_city` = `e`.`id`))) left join `bpms`.`biz_apply_order` `f` on ((`f`.`product_id` = `b`.`product_id`)));

