create view viewgetinsureperiod as
  select `a`.`partner_id`        AS `insureId`,
         `a`.`product_name`      AS `productName`,
         `a`.`day_before_expire` AS `dayBeforeExpire`,
         `a`.`link_partner_id`   AS `bankName`
  from (`bpmsv2`.`s_finance_channel` `a` left join `bpmsv2`.`s_partner_info` `b` on ((`a`.`partner_id` =
                                                                                      `b`.`partner_id`)));

