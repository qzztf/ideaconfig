create view policy_product_end_view as
  select (`isr`.`bank_loan_time` + interval `fee`.`product_term` day) AS `policy_product_end`,
         `fee`.`apply_no`                                             AS `apply_no`
  from (`bpmsv2`.`biz_fee_summary` `fee` join `bpmsv2`.`biz_isr_mixed` `isr` on ((
    (`fee`.`apply_no` = `isr`.`apply_no`) and (`fee`.`apply_no` is not null) and (`fee`.`apply_no` <> '') and
    (`isr`.`bank_loan_time` is not null))));

