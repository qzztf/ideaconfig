create view plat_due_date_view as
  select `bpmsv2`.`biz_fee_summary`.`apply_no`                                                                       AS `apply_no`,
         (`bpmsv2`.`biz_fee_summary`.`platform_value_date` +
          interval `bpmsv2`.`biz_fee_summary`.`product_term` day)                                                    AS `platform_due_date`,
         `bpmsv2`.`biz_fee_summary`.`platform_value_date`                                                            AS `platform_value_date`,
         `bpmsv2`.`biz_fee_summary`.`product_term`                                                                   AS `product_term`
  from `bpmsv2`.`biz_fee_summary`
  where ((`bpmsv2`.`biz_fee_summary`.`platform_value_date` is not null) and
         (`bpmsv2`.`biz_fee_summary`.`platform_value_date` <> '') and
         (`bpmsv2`.`biz_fee_summary`.`product_term` is not null) and (`bpmsv2`.`biz_fee_summary`.`product_term` <> ''));

