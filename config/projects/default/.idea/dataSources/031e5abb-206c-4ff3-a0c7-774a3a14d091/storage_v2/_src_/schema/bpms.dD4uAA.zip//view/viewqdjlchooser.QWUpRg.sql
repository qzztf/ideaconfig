create view viewqdjlchooser as (select `c`.`fullname_`                     AS `salesName`,
                                       `c`.`id_`                           AS `salesId`,
                                       concat(left(`e`.`CODE_`, 3), '000') AS `companyCode`,
                                       `e`.`CODE_`                         AS `salesBranchId`
                                from ((((`bpms`.`sys_role` `a` left join `bpms`.`sys_user_role` `b` on ((`a`.`ID_` =
                                                                                                         `b`.`role_id_`))) left join `bpms`.`sys_user` `c` on ((
                                  `b`.`user_id_` = `c`.`id_`))) left join `bpms`.`sys_org_user` `d` on ((`c`.`id_` =
                                                                                                         `d`.`USER_ID_`))) left join `bpms`.`sys_org` `e` on ((
                                  `d`.`ORG_ID_` = `e`.`ID_`)))
                                where ((`a`.`ALIAS_` = 'QDJLG') and (`c`.`fullname_` is not null)));

