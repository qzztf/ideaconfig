create view v_company_account as
  select `a`.`id`             AS `id`,
         `a`.`acct_type`      AS `acct_type`,
         `a`.`acct_no`        AS `acct_no`,
         `a`.`acct_name`      AS `acct_name`,
         `a`.`open_bank_name` AS `open_bank_name`,
         `a`.`open_bank_code` AS `open_bank_code`,
         `a`.`remark`         AS `remark`,
         `b`.`id`             AS `bId`,
         `b`.`purpose_type`   AS `purpose_type`,
         `b`.`buss_type`      AS `buss_type`,
         `b`.`pay_type`       AS `pay_type`,
         `b`.`area_code`      AS `area_code`,
         `b`.`partner_code`   AS `partner_code`,
         `b`.`account_codes`  AS `account_codes`
  from (`bpms`.`b_account_info` `a` join `bpms`.`b_account_rel` `b` on (find_in_set(`a`.`id`, `b`.`account_codes`)));

